Build with Node.js 22 and npm.

1. Unzip this source archive.
2. Run npm ci in the extracted folder.
3. Run npm run build:firefox.
4. The extension is in .output/firefox-mv3/.

WXT bundles and minifies the code; Svelte compiles the popup templates. No secrets or additional files are needed.
